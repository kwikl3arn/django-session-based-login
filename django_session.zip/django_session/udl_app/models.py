from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    office_phone = models.CharField(max_length=12, blank=True)
    mobile_phone = models.CharField(max_length=12, blank=True)
    email_confirmed = models.BooleanField(default=False)
    organization_type = models.CharField(max_length=50, blank=True)
    organization_id=models.BigIntegerField(blank=True,default=0)
    citizen = models.TextField(blank=True)
    position = models.TextField(blank=True)
    reason = models.TextField(blank=True)
    created_on = models.DateTimeField(auto_now_add=True)


class Organization(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    org_name = models.TextField(blank=False)
    org_addr1 = models.TextField(blank=False)
    org_addr2 = models.TextField(blank=True)
    org_city = models.TextField(blank=False)
    org_state = models.TextField(blank=False)
    org_postcode = models.TextField(blank=False)
    org_country = models.TextField(blank=False)
    created_on = models.DateTimeField(auto_now_add=True)


class Country(models.Model):
    country_name = models.TextField(blank=True)
    created_on = models.DateTimeField(auto_now_add=True)


class User_uploaded_files(models.Model):
    userid = models.IntegerField()
    file_trcode = models.TextField(blank=True)
    file_name = models.TextField(blank=True)
    file_visible = models.TextField(blank=True)
    file_description = models.TextField(blank=True)
    uploaded_on = models.DateTimeField(auto_now_add=True)


class uploaded_files(models.Model):
    userid = models.IntegerField()
    fileid = models.TextField(blank=True)
    file_trcode = models.TextField(blank=True)
    filename = models.TextField(blank=True)
    file_url = models.TextField(blank=True)
    uploaded_on = models.DateTimeField(auto_now_add=True)


class FIle_approvel(models.Model):
    file_trcode = models.TextField(blank=True)
    requested_userid = models.IntegerField()
    requested_fileid = models.IntegerField()
    requested_on = models.DateTimeField(auto_now_add=True)
    email_cc = models.TextField(blank=True)
    justification = models.TextField(blank=True)
    uploaded_owner_id = models.IntegerField()
    owner_granted = models.CharField(max_length=50)


class Trcode(models.Model):
    trcode_yrmm = models.CharField(max_length=7, blank=True)
    trcode_count = models.BigIntegerField(default=1)
