from django.shortcuts import render
import collections
from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse, HttpResponseRedirect
from django.template.loader import render_to_string
from django.views.generic import ListView, UpdateView, DetailView, DeleteView, View, CreateView, RedirectView
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse, reverse_lazy
from django.views import generic
from django.contrib.auth.forms import UserChangeForm
from django.contrib.auth.views import PasswordChangeView
from django.contrib import messages
from django.contrib.auth.models import User
from django.conf import settings
from udl_app.models import *
from django.core.files.storage import FileSystemStorage
import time
from datetime import datetime
from django.db import connection
from django.http import JsonResponse
from django.db import transaction


def custom_decorator_logincheck(function):
    # print('custom_decorator_logincheck', function)

    def _function(request, *args, **kwargs):
        if request.session.get('user_email') is None:
            # if empty means, empty string
            # if request.session.get('user_email') is not None\
            # and not request.session.get('user_email'):
            return redirect('login')
        return function(request, *args, **kwargs)

    return _function


# login validation view
def login_page(request):
    # get yearmonth from trcode,
    # if yearmonth not exist then insert yearmonth in trcode_yymm
    now = time.time()
    year_month = datetime.fromtimestamp(now).strftime('%Y%m')
    # print('year_month=', year_month)
    trcode = Trcode.objects.filter(trcode_yrmm=year_month)
    if len(trcode) < 1:
        Trcode.objects.create(trcode_yrmm=year_month)
    if request.user.is_authenticated:
        return redirect(settings.LOGIN_REDIRECT_URL)
    elif request.method == "POST":
        email = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)
        if user is None:
            User = get_user_model()
            user_queryset = User.objects.all().filter(email__iexact=email)
            if user_queryset:
                username = user_queryset[0].username
                user = authenticate(username=username, password=password)
                # if user created password with out hashing, it will check over here
                if user is None:
                    User = get_user_model()
                    user = User.objects.filter(email=email, password=password).exists()
                    # if user is not exist it will return none
                    if user == False:
                        user = None
        if user is not None:
            try:
                try:
                    login(request, user)
                except Exception as e:
                    pass

                request.session.set_expiry(14400)  # session expire in 4 hrs
                User = get_user_model()
                user_queryset = User.objects.all().filter(email__iexact=email)
                request.session['user_email'] = user_queryset[0].email
                request.session['user_id'] = user_queryset[0].id
                request.session['user_name'] = user_queryset[0].username
                # request.session['_session_expiry'] = 14400
                print('user loged in:', request.user.is_authenticated)
            except AttributeError:
                # if user created password with out hashing, it will check over here
                # session creation
                request.session['user_email'] = user[0].email
                request.session['user_id'] = user[0].id
                request.session['user_name'] = user[0].username
            # for key, value in request.session.items():
            #     print('{} => {}'.format(key, value))
            # if user clicked something which is required login,
            # after login it will redirect to that page,what ever user clicked
            if 'next' in request.GET:
                return redirect(request.GET['next'])
            else:
                return redirect('home')

        else:
            return render(request, 'login.html', context={'msg': 'Invalid User Name / Password'})
    else:

        return render(request, 'login.html', context={})


def logout_view(request):
    try:
        logout(request)
    except:
        try:
            del request.session['user_email']
        except:
            return redirect('login')
    return redirect('login')


@custom_decorator_logincheck
def home(request):
    return render(request, 'home.html')


@custom_decorator_logincheck
def file_upload(request):
    if request.method == 'POST':
        print(request.POST)
        files = request.FILES.getlist("files")
        now = time.time()
        stamp = datetime.fromtimestamp(now).strftime('%Y-%m-%d-%H-%M-%S')
        year_month = datetime.fromtimestamp(now).strftime('%Y%m')
        trcode = Trcode.objects.filter(trcode_yrmm=year_month)
        trcode_count = trcode[0].trcode_count
        trcode_year = trcode[0].trcode_yrmm
        trcode = trcode_year.ljust(11, '0')
        final_tr = int(trcode) + int(trcode_count)
        fs = FileSystemStorage()
        # up = uploaded_files()
        user_up = User_uploaded_files()
        user_up.userid = request.session['user_id']
        user_up.file_name = request.POST.get('filename')
        user_up.file_visible = request.POST.get('file_type')
        user_up.file_description = request.POST.get('Description')
        user_up.file_trcode = final_tr
        user_up.save()
        for x in files:
            filename = fs.save(str(stamp) + str(x.name), x)
            uploaded_file_url = fs.url(filename)
            uploaded_files.objects.create(filename=filename, file_url=uploaded_file_url,
                                          userid=request.session['user_id'], file_trcode=final_tr)
        Trcode.objects.filter(trcode_yrmm=year_month).update(trcode_count=int(trcode_count) + 1)
        return render(request, 'file_upload.html', context={'msg': 'files uploaded'})


    else:
        return render(request, 'file_upload.html')


@transaction.atomic
def registration(request):
    if request.method == "POST":
        user = User()
        profile = Profile()
        org = Organization()
        user_slected_org_type = request.POST.get('org')
        email = request.POST.get('email')
        user.first_name = request.POST.get('fname')
        middle_name = request.POST.get('mname')
        user.last_name = request.POST.get('lname')
        user.email = request.POST.get('email')
        user.username = email
        user.set_password('udl123')  # hashing password
        print('--------------')
        # if email_check(user):
        #     return render(request, 'register.html', {'msg': 'User Already Exist'})
        user.save()
        u = User.objects.get(email=email)
        profile.user = User.objects.get(id=u.id)
        profile.office_phone = request.POST.get('office_phone')
        profile.mobile_phone = request.POST.get('mobile_phone')
        profile.organization_type = request.POST.get('org')
        profile.organization_id = request.POST.get('org_list', 0)
        profile.position = request.POST.get('dd')
        profile.citizen = request.POST.get('nn')
        profile.reason = request.POST.get('reason')
        profile.save()
        if user_slected_org_type != 'select_org':
            org.user = User.objects.get(id=u.id)
            org.org_name = request.POST.get('Organization')
            org.org_addr1 = request.POST.get('Address')
            org.org_addr2 = request.POST.get('Address_2')
            org.org_city = request.POST.get('City')
            org.org_state = request.POST.get('State')
            org.org_postcode = request.POST.get('zip')
            org.org_country = request.POST.get('Country')
            org.save()
        # licence_accept = request.POST.get('accept')
        return redirect('login')

    else:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT * FROM udl_app_profile "
                "join udl_app_organization on udl_app_organization.user_id=udl_app_profile.user_id "
                "where organization_type not in ('select_org')")
            org = cursor.fetchall()
        return render(request, 'register.html', {'org': org})


@custom_decorator_logincheck
def provider_discovery(request):
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT * FROM udl_app_user_uploaded_files "
            "join auth_user on auth_user.id= udl_app_user_uploaded_files.userid "
            "join udl_app_organization on udl_app_organization.user_id=udl_app_user_uploaded_files.userid "
            "join udl_app_profile on udl_app_profile.user_id=udl_app_user_uploaded_files.userid")
        file_list = cursor.fetchall()
    return render(request, 'provider_discovery.html', {'file_list': file_list})


def org_info(request):
    if request.method == 'GET':
        org_id = request.GET.get('org_id')
        org_info = Organization.objects.get(id=org_id)
        json_data = [{'Address': org_info.org_addr1, 'City': org_info.org_city, 'Postcode': org_info.org_postcode,
                      'State': org_info.org_state, 'Country': org_info.org_country}]
        return JsonResponse(json_data, safe=False)


def email_check(request):
    if request.method == 'GET':
        email_id = request.GET.get('uemail')
        print('emailid=', email_id)
        users = User.objects.filter(email=email_id).count()
        print('users=', users)
        if users == 1:
            return HttpResponse('1')  # Email exist
        else:
            return HttpResponse('0')  # Email not exist
